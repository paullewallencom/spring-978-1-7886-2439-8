package springfive.cms.domain.models;

import lombok.Data;

/**
 * @author claudioed on 28/10/17. Project cms
 */
@Data
public class Category {

  String id;

  String name;

}
