package springfive.cms.domain.vo;

import lombok.Data;

/**
 * @author claudioed on 29/10/17. Project cms
 */
@Data
public class CategoryRequest {

  String name;

}
