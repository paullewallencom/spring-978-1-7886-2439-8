package springfive.cms.domain.repository;

import org.springframework.stereotype.Service;
import springfive.cms.domain.models.User;

@Service
public class UserRepository extends AbstractRepository<User>{}
