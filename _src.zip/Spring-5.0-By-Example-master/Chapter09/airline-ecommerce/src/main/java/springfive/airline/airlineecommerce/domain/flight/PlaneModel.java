package springfive.airline.airlineecommerce.domain.flight;

import lombok.Data;

@Data
public class PlaneModel {

  String factory;

  String model;

  String name;

}