package springfive.airline.airlineecommerce.domain.resource.data;

import lombok.Data;

@Data
public class BookingRequest {

  String fareId;

}
