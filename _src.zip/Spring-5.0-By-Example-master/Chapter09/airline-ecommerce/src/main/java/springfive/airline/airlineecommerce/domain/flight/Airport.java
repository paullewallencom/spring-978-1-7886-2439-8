package springfive.airline.airlineecommerce.domain.flight;

import lombok.Data;

@Data
public class Airport {

  String name;

  String code;

  String city;

  String country;

}
