package springfive.airline.airlineecommerce.domain.flight;

import lombok.Data;

@Data
public class Plane {

  String id;

  PlaneModel model;

}
