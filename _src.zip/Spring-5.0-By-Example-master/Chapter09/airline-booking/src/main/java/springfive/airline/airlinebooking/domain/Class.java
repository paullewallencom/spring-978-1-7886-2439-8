package springfive.airline.airlinebooking.domain;

import lombok.Data;

@Data
public class Class {

  String id;

  String name;

}
