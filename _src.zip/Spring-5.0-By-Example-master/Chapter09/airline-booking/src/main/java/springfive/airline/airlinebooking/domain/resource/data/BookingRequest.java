package springfive.airline.airlinebooking.domain.resource.data;

import lombok.Data;

@Data
public class BookingRequest {

  String fareId;

}
