package springfive.airline.airlinefare.domain;

/**
 * @author claudioed on 24/02/18.
 * Project airline-fare
 */
public class FlightRequest {

}
