package springfive.airline.airlinefare.domain.flight;

import lombok.Data;

@Data
public class FlightRequest {

  private String id;

}
