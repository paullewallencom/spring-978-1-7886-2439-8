package springfive.airline.infra.route;

/**
 * @author claudioed on 08/01/18.
 * Project gateway
 */
public class SampleRoute {

}
