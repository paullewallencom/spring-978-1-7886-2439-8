package springfive.twittertracked.domain

/**
 * @author claudioed on 06/12/17.
 * Project twitter-consumer
 */
data class TrackedHashTag(val hashTag: String,val queue:String )