package springfive.airline.airlinefare.domain;

import lombok.Data;

@Data
public class PassengerDocument {

  String name;

  String value;

}
