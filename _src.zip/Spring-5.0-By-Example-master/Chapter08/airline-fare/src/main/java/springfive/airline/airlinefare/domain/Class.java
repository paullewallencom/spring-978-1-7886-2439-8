package springfive.airline.airlinefare.domain;

import lombok.Data;

@Data
public class Class {

  String id;

  String name;

}
