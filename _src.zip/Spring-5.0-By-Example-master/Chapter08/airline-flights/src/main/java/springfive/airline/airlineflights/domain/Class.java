package springfive.airline.airlineflights.domain;

import lombok.Data;

@Data
public class Class {

  String id;

}
