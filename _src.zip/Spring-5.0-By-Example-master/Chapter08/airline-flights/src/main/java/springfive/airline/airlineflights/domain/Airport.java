package springfive.airline.airlineflights.domain;

import lombok.Data;

@Data
public class Airport {

  String name;

  String code;

  String city;

  String country;

}
