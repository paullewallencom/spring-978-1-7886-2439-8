package springfive.airline.airlineflights.domain;

import lombok.Data;

@Data
public class PlaneModel {

  String factory;

  String model;

  String name;

}